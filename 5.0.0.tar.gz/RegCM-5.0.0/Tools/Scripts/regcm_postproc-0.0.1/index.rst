.. RegCM postprocessing tool documentation master file, created by
   sphinx-quickstart on Thu Mar 20 18:08:47 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to RegCM postprocessing tool's documentation!
=====================================================

RegCM postprocessing tool allows the users of the Regional Climate Model to quickly compare the results of the simulations with actual weather observations 
from the Climate Research Unit.

It has capability to calculate monthly average. It is taking the model and the observed data as input with their corresponding start and end date. Then it will return the average for each month for the given range

Contents:

.. toctree::
   :maxdepth: 2

   classes

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

