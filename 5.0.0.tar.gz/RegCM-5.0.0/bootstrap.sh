#!/bin/bash

autoreconf -f -i # -I /home/uturunco/progs/libtool-2.4/share/aclocal
